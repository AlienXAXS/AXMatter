data:extend({
  {
    type = "recipe-category",
    name = "ax-matter-lab"
  },
  {
	type = "recipe",
	name = "ax-matter-lab",
	enabled = false,
	energy_required = 20,
	ingredients =
	{
		{"lab", 1},
		{"steel-plate", 10},
		{"electronic-circuit", 100},
		{"pipe", 20},
	},
	result = "ax-matter-lab"
  }
})